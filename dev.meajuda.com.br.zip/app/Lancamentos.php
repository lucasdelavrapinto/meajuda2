<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lancamentos extends Model
{
    protected $table = 'lancamentos';
	public $timestamps = false;
}
